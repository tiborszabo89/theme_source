<?php get_header(); ?>

<!-- Vue wrapper -->
<div class="container" id="app">
<div>
<!-- ---- -->

<?php get_footer(); ?>
